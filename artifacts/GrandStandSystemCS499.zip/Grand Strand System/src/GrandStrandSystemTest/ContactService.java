package GrandStrandSystemTest;


import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import GrandStandSystemClass.Contact;

class ContactService {


@Test
	
void testAddContact() {
	ContactService contactService = new ContactService();
	Contact contact1 = new Contact("1234567890", "Bruno", "Mars","9153334455", "123 Elm st");
	Contact contact2 = new Contact("1234567890", "Bruno", "Mars","9153334455", "123 Elm st");
	
	
	}


	@Test
	void testDeleteContact() {
		ContactService contactService = new ContactService();
		Contact contact1 = new Contact("1234567890", "Bruno", "Mars","9153334455", "123 Elm st");
		
		contactService.addContact(contact1);
		contactService.deleteContact("1234567890");
		
		assertTrue(contact1.getFirstName().equals("Bruno"));
}


	private void deleteContact(String string) {
		// TODO Auto-generated method stub
		
	}
	@Test
	void testUpdateContact(){
		ContactService contactService =  new ContactService();
		Contact contact1 = new Contact("1234567890", "Bruno", "Mars","9153334455", "123 Elm st");
		
		contactService.addContact(contact1);
		contactService.updateContact("1234567890",1,"Bruno");
		
		assertTrue(contact1.getFirstName().equals("Bruno"));
		
		contactService.updateContact("1234567890",2,"Mars");
		assertTrue(contact1.getLastName().equals("Mars"));
		
		( contactService).updateContact("1234567890",3,"9153334455");
		assertTrue(contact1.getNumber().equals("9153334455"));
		
		contactService.updateContact("1234567890",4,"123 Elm st");
		assertTrue(contact1.getAddress().equals("123 Elm st"));
		
		
		
	}
	private void addContact(Contact contact1) {
		// TODO Auto-generated method stub
		
	}
	private void updateContact(String string, int i, String string2) {
		// TODO Auto-generated method stub
		
	}
}
