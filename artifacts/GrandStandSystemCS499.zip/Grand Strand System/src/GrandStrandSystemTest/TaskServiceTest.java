package GrandStrandSystemTest;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import GrandStandSystemClass.TaskService;

class TaskServiceTest {

	@AfterEach
	void tearDown() throws Exception{
		TaskService.tasks.clear();
	}
	@DisplayName("Add a Task")
	@Test
	void testAddUniqueTask() {
		//string in used
		String id = "1234567890";
		String fullName = "Bruno Mars";
		String description = "This is a good description";
		//task service
		TaskService service = new TaskService();
		
		assertEquals(0, TaskService.tasks.size());
		
		service.addUniqueTask(fullName, description);
		
		assertTrue(TaskService.tasks.containsKey(id));
		assertEquals(fullName, TaskService.tasks.get(id).getName());
		assertEquals(description, TaskService.tasks.get(id).getDescription());
		
	}
	//to delete contact 
	@DisplayName("Test delete Contact")
	//testing subject for delete name task
	@Test void testDeleteTask() {
		String fullName = "Bruno Mars";
		String description = "This is a good description";
		
		TaskService service = new TaskService();
		//assert equals
		assertEquals(3,TaskService.tasks.size());
		
		service.deleteTasks("1");
		
		assertEquals(2, TaskService.tasks.size());
		assertFalse(TaskService.tasks.containsKey("1"));
		
	}
	//test update with a invalid ID
	@DisplayName("Test update Task with a invalid ID")
	@Test void testBadUpdateTasks() {
		String id = "1234567890";
		String fullName = "Bruno Mars";
		String description = "This is a good description";
		
		TaskService service = new TaskService();
		//unique task needed 
		service.addUniqueTask(fullName, description);
		//assert equals
		service.updateTasks("0", fullName, "New description");
		assertEquals("New description", TaskService.tasks.get(id).getDescription());
		assertEquals(fullName, TaskService.tasks.get(id).getName());
		
		
	}
	//test with a valid ID
	@DisplayName("Test update Task with a valid ID")
	@Test void testUpdateTasks() {
		String id = "1234567890";
		String fullName = "Bruno Mars";
		String description = "This is a good description";
		//temp task assign to new task service
		TaskService service = new TaskService();
		
		service.addUniqueTask(fullName, description);
		//assert equals
		service.updateTasks("0", fullName, "New description");
		assertEquals("New description", TaskService.tasks.get(id).getDescription());
		assertEquals(fullName, TaskService.tasks.get(id).getName());

	}

}
