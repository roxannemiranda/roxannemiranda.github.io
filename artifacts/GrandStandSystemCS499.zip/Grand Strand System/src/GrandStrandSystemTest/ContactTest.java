package GrandStrandSystemTest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import GrandStandSystemClass.Contact;
class ContactTest {
	
	@Test
	void testContactClass() {
		Contact contact = new Contact("123456790", "Bruno", "Mars", "9153334455", "123 Elm st");
		assertTrue(contact.getContactId().equals("1234567890"));
		assertTrue(contact.getFirstName().equals("Bruno"));
		assertTrue(contact.getLastName().equals("Mars"));
		assertTrue(contact.getNumber().equals("9153334455"));
		assertTrue(contact.getAddress().equals("123 Elm st"));
	}
	
	@Test
	void testContactIdTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1234567890", "Bruno", "Mars", "9153334455", "123 Elm st");
		});
	}
		@Test
		void testContactIdNull() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Contact("1234567890", "Bruno", "Mars", "9153334455", "123 Elm st");
			});
		}
		@Test
		void testContactFirstNameTooLong() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Contact("1234567890", "Bruno", "Mars", "9153334455", "123 Elm st");
			});
		}
		@Test
		void testContactFirstNameNull() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Contact("1234567890", "Bruno", "Mars", "9153334455", "123 Elm st");
			});
		}
		@Test
		void testContactLastNameTooLong() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Contact("1234567890", "Bruno", "Mars", "9153334455", "123 Elm st");
			});
		}
		@Test
		void testContactLastNameNull() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Contact("1234567890", "Bruno", "Mars", "9153334455", "123 Elm st");
			});
		}
		@Test
		void testContactNumberTooLong() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Contact("1234567890", "Bruno", "Mars", "9153334455", "123 Elm st");
			});
		}
		
		@Test
		void testContactNumberNull() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Contact("1234567890", "Bruno", "Mars", "9153334455", "123 Elm st");
			});
		}
		
		@Test
		void testContactsAddressTooLong() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Contact("1234567890", "Bruno", "Mars", "9153334455", "123 Elm st");
			});
		}
		@Test
		void testContactAddressNull() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Contact("1234567890", "Bruno", "Mars", "9153334455", "123 Elm st");
			});
		}
		
		@Test
		public void setContactId() {
			Contact instance = new Contact("1234567890", "Bruno", "Mars", "9153334455", "123 Elm st");
				instance.setContactId("1234567890");
				assertEquals("1234567890", instance.getContactId());

	}
		@Test
		public void setFirstName() {
			Contact instance = new Contact("1234567890", "Bruno", "Mars", "9153334455", "123 Elm st");
				instance.setfirstName("Bruno");
				assertEquals("Bruno", instance.getFirstName());
		}
		
		@Test
		public void setLastName() {
			Contact instance = new Contact("1234567890", "Bruno", "Mars", "9153334455", "123 Elm st");
				instance.setlastName("Mars");
				assertEquals("Mars", instance.getLastName());
		}
		
		@Test
		public void setNumber() {
			Contact instance = new Contact("1234567890", "Bruno", "Mars", "9153334455", "123 Elm st");
				instance.setNumber("9153334455");
				assertEquals("9153334455", instance.getNumber());
		}
		@Test
		public void setAddress() {
			Contact instance = new Contact("1234567890", "Bruno", "Mars", "9153334455", "123 Elm st");
				instance.setaddress("9153334455");
				assertEquals("123 Elm st", instance.getAddress());
		}
		

}
