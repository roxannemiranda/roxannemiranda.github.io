package GrandStrandSystemTest;

import java.time.LocalDate;
import java.util.HashMap;

import GrandStandSystemClass.Appointment;
import GrandStandSystemClass.AppointmentService;

class AppointmentServiceTest {
	private HashMap <Integer, Appointment > apptMap;
	private int apptId;
	
	public void AppointmentService() {
		HashMap apptMap = new HashMap <>();
		apptId = 1;
		
		
	}
	//add appointment with requirements
	
	public void addAppt(LocalDate date, String Description) {
		String apptIdString = String.valueOf(apptId);
		Appointment appointment = new Appointment(apptIdString, date, Description);
		apptMap.put(apptId, appointment);
		apptId++;
		
	}
	
	public Appointment deleteAppt(int id) {
		if(isNull(id)) {
			throw new IllegalArgumentException("Invalid ID");
			
		}
		
		return apptMap.remove(id);
	}
	
	public Appointment getAppt(int id) {
		if(isNull(id)) {
			throw new IllegalArgumentException("Invalid ID");
		}
		return apptMap.get(id);
	}
	
	private boolean isNull (int id) {
		if (apptMap == null || !apptMap.containsKey(id)) {
			return true;
		}
		
		return false;
	}



}
