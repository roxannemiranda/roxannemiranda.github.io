package GrandStrandSystemTest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;


	import org.junit.jupiter.api.Assertions;

	import static org.junit.Assert.assertEquals;
	import org.junit.jupiter.api.DisplayName;

	import GrandStandSystemClass.Task;
	//task test 
	class TaskTest {
		@DisplayName("Good constructor")
		@Test void goodConstructor() {
			//testing
			String id = "1234567890";
			String fullName = "Bruno Mars";
			String description = "This is a good description";
			//task temptask assign to new task
			Task task = new Task(id, fullName, description);
			//assert equals
			assertEquals(1, task.getUniqueID());
			assertEquals(fullName, task.getName());
			assertEquals(description, task.getDescription());
			
		}
		//testing for invalid constructor
		@DisplayName("Invalid constructor")
		@Test void invalidConstructor() {
			//string being used for testing
			String id = "1234567890";
			String fullName = "Bruno Mars";
			String description = "This is a good description";
			//Assertions for illegal argument
			Assertions.assertThrows(IllegalArgumentException.class,() ->{
				new Task(id, fullName, description);
			});
		}
		//testing for invalid constructor using a long ID
		@DisplayName("Invalid constructor with long ID")
		@Test void invalidIDConstructor() {
			//string being testing
			String id = "123456789121234";
			String fullName = "Bruno Mars";
			String description = "description";
			//assertions for illegal argument
			Assertions.assertThrows(IllegalArgumentException.class,() ->{
				new Task(id, fullName, description);
			});
		}
		
		@DisplayName("Invalid constructor with long ID")
		@Test void invalidNullConstructor() {
			String id = "null";
			String fullName = "Bruno Mars";
			String description = "description";
			
			Assertions.assertThrows(IllegalArgumentException.class,() ->{
				new Task(id, fullName, description);
			});
		}
		//testing a valid set name
		@DisplayName("Test a valid setName")
		@Test 
		public void testGoodName() {
			//string being testing
			String id = "1234567890";
			String fullName = "Bruno Mars";
			String description = "This is a good description";
			//task temp task assign to new task
			Task task = new Task(id, fullName, description);
			task.setName("Test Name");
			//assert equals matching test name
			assertEquals("Test Name", task.getName());
		}
		//test for a invalid null for a set name
		@DisplayName("Test an invalid null set Name")
		@Test
		public void testNullName() {
			//test null name
			String id = "1234567897";
			String fullName = "Jennifer Lopez";
			String description = "This is a good description";
			//task temp task assign to new task
			Task task = new Task(id, fullName, description);
			
			Assertions.assertThrows(IllegalArgumentException.class,() -> {
				task.setName(null);
			});
		}
		//test with an invalid long name
		@DisplayName("Test an invalid long Name")
		@Test
		public void testLongName() {
			//string being tested
			String id = "1234567890";
			String fullName = "Bruno Mars";
			String description = "This is a good description";
			
			Task task = new Task(id, fullName, description);
			
			Assertions.assertThrows(IllegalArgumentException.class,() -> {
				task.setName("The name being use is too long");
			});
		}
		//test for a empty name which then is invalid
		@DisplayName("Test an invalid Empty Name")
		@Test
		public void testEmptyName() {
			String id = "1234567890";
			String fullName = "Bruno Mars";
			String description = "This is a good description";
			
			Task task = new Task(id, fullName, description);
			
			Assertions.assertThrows(IllegalArgumentException.class,() -> {
				task.setName(" Error Empty ");
			});
		}
		//test becomes invalid because the description is empty
		@DisplayName("Test an invalid Empty Description")
		@Test
		public void testNullDescription() {
			//string testing
			String id = "1234567890";
			String fullName = "Bruno Mars";
			String description = "This is a good description";
			//task temp task assign to new task
			Task task = new Task(id, fullName, description);
			
			Assertions.assertThrows(IllegalArgumentException.class,() -> {
				task.setName(" null ");
			});
		}
		

		


	}


