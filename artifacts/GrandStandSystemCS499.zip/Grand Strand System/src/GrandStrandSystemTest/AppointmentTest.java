package GrandStrandSystemTest;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.util.Date;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import GrandStandSystemClass.Appointment;

class AppointmentTest {

	private Appointment appointment;
	private LocalDate date;

 {
	 //set local date
	 
		 date = LocalDate.of(2024, 10,5);
		
		
 }
			void appointmentTest() {

			appointment = new Appointment("3334445555",date, "this is a fifty" + "character description for the test");
			  assert equals(appointment.getContactId());
			  assert equals(appointment.getDate());
			  assert equals(appointment.getDescription());
			  
		
			  }
		  
 //all test
 	@Test
 		void updateDateTest() {
 		appointment = new Appointment("3334445555", date, "this is a fifty" + "character description for the test");
 		LocalDate date2 = LocalDate.of(2024, 10, 30);
 		appointment.setDate(date2);
 		 assert equals (appointment.getDate());
 	}
		  
		  private void assetEquals(LocalDate date2, LocalDate date22) {
		// TODO Auto-generated method stub
		
	}
// invalid iD
		  
		  @DisplayName("Invalid constructor with long ID")
			@Test void invalidIDConstructor() {
				//string being testing
				String id = "123456789121234";
				
				String description = "description";
				//assertions for illegal argument
				Assertions.assertThrows(IllegalArgumentException.class,() ->{
					 appointment = new Appointment(id, date, description);
				});
		  }
		  


@DisplayName("Invalid constructor with long ID")
@Test void invalidNullConstructor() {
	String id = "null";
	
	String description = "description";
	
	Assertions.assertThrows(IllegalArgumentException.class,() ->{
		Appointment appointment2 = new Appointment( description, date, description);
	});
}

@DisplayName("Test an invalid Empty Description")
@Test
public void testNullDescription() {
	//string testing
	String id = "1234567897";
	
	String description = "This is a good description";
	//appoint assign to new appointment
	Appointment appointment = new Appointment(id,  date, description);
	
	Assertions.assertThrows(IllegalArgumentException.class,() -> {
		appointment.setName(" null ");
	});
}

		  

	}




