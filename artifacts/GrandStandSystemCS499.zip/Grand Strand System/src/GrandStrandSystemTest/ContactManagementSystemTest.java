package GrandStrandSystemTest;

import org.junit.jupiter.api.BeforeEach; 

import org.junit.jupiter.api.Test;

import GrandStandSystemClass.Contact1;

import static org.junit.jupiter.api.Assertions.*; 
class ContactManagementSystemTest { 
    private ContactManagementSystemTest cms; 

 // new texting system implemented for CS-499

    @BeforeEach 
    public void setUp() { 
        cms = new ContactManagementSystemTest(); 
        // Adding initial contacts for testing 
        cms.addContact(new Contact1("1", "Alice", "alice@example.com", "123-456-7890")); 
        cms.addContact(new Contact1("2", "Bob", "bob@example.com", "987-654-3210")); 
    } 
 

    @Test 
    public void testAddContact() { 
        Contact1 newContact = new Contact1("3", "Charlie", "charlie@example.com", "555-666-7777"); 
         (cms).addContact(newContact); 
        assertEquals(newContact, cms.searchContact("3")); 
    } 
 
    @Test 
    public void testSearchContact() { 
        Contact1 contact = cms.searchContact("1"); 
        assertNotNull(contact); 
        assertEquals("Alice", contact.getName()); 
    } 
 
    @Test 

    public void testUpdateContact() { 
        cms.updateContact("1", "Alice Smith", null, "111-222-3333"); 
        Contact1 updatedContact = cms.searchContact("1"); 
        assertEquals("Alice Smith", updatedContact.getName()); 
        assertEquals("111-222-3333", updatedContact.getPhone()); 
    } 

 

    @Test 
    public void testDeleteContact() { 
        cms.deleteContact("2"); 
        assertNull(cms.searchContact("2")); 
    } 

 

    @Test 
    public void testDisplayContacts() { 
        // Since displayContacts prints to console, we'll just check the size of the contacts map 
        assertEquals(2, cms.contacts.size()); 
    } 
    @Test 
    public void testUpdateNonExistentContact() { 
        cms.updateContact("999", "Nonexistent", "nonexistent@example.com", "000-000-0000"); 
        // No exception should be thrown and the contacts count should remain the same 
        assertEquals(2, cms.contacts.size()); 

    } 
} 