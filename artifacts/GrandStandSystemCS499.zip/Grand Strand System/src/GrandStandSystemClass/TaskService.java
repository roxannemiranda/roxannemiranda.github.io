package GrandStandSystemClass;

import java.util.ArrayList;
import java.util.HashMap;

import GrandStandSystemClass.Task;

public class TaskService {
	//public static with hashmap since we are using a unique ID
			public static HashMap < String, Task> tasks = new HashMap <String, Task>();
			ArrayList<Task> list = new ArrayList <Task>();
			
			//ID Must be unique
			@SuppressWarnings("static-access")
			public boolean addTask(Task task) {
				boolean didAdd = false;
				//list is empty
				
			
				if (list.size()==0) {
					list.add(task);
					didAdd = true;
				}
				
				
				else {
					for(Task s : list) {
						if(((java.lang.String) task.getID()).equalsIgnoreCase(s.getID())){
							return didAdd;
						}
					}
					
					list.add(task);
				}
				return didAdd;
				//recommendations added from debug variables being used on unit testing
			}

			

			public void deleteTasks(String string) {
				// TODO Auto-generated method stub
				
			}

			public void addUniqueTask(java.lang.String fullName2, java.lang.String description) {
				// TODO Auto-generated method stub
				
			}

			public void updateTasks(java.lang.String string2, java.lang.String fullName2, java.lang.String string3) {
				// TODO Auto-generated method stub
				
			}
		}


