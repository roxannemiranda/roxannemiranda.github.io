package GrandStandSystemClass;


	import java.time.LocalDate;
import java.util.Date;
	public class Appointment{
		
		private String ContactID;
		private Date date;
		private String Description;
		
		public Appointment(String uniqueID,  LocalDate date2, String Description){
			// if contact Id is null, and contact ID is 10 character
			if(uniqueID == null || uniqueID.length() > 10) {
				//argument if contact ID is incorrect
			 throw new IllegalArgumentException("Invalid ID");
			}
			// creating a class with first Name
			if(date == null|| date.before(new Date())) {
				throw new IllegalArgumentException("Invalid Date");
			}
			// creating a class with first Name
			if(Description == null|| Description.length() > 50) {
				throw new IllegalArgumentException("Invalid Description");
			}
			
			this.ContactID = uniqueID;
			this.date = date;
			this.Description = Description;

		}

		public Object getContactId() {
			// TODO Auto-generated method stub
			return null;
		}

		public Object getDate() {
			// TODO Auto-generated method stub
			return null;
		}

		public Object getDescription() {
			// TODO Auto-generated method stub
			return null;
		}

		public void setDate(LocalDate date2) {
			// TODO Auto-generated method stub
			
		}

		public void setName(String string) {
			// TODO Auto-generated method stub
			
		}



}
