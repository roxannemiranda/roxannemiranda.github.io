package GrandStandSystemClass;


	import java.util.ArrayList;
	public class AppointmentService{


	
		ArrayList<Appointment> list = new ArrayList <Appointment>();
		
		//ID Must be unique
		public boolean addAppointment(Appointment appointment) {
			boolean didAdd = false;
			//list is empty
			
		
			if (list.size()==0) {
				list.add(appointment);
				didAdd = true;
			}
			
			
			else {
				for(Appointment s : list) {
					if(((String) appointment.getContactId()).equalsIgnoreCase((String) s.getContactId())){
						return didAdd;
					}
				}
				
				list.add(appointment);
			}
			return didAdd; 
		}
			
			String getId() {
				// TODO Auto-generated method stub
				return null;
			
		}
	

		
	}



