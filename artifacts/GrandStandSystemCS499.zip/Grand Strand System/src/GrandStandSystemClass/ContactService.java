package GrandStandSystemClass;


	import java.util.ArrayList;
	public class ContactService {
	
		ArrayList<Contact> list = new ArrayList <Contact>();
		
		//ID Must be unique
		public boolean addContact(Contact contact) {
			boolean didAdd = false;
			//list is empty
			
		
			if (list.size()==0) {
				list.add(contact);
				didAdd = true;
			}
			
			
			else {
				for(Contact s : list) {
					if(contact.getContactId().equalsIgnoreCase(s.getContactId())){
						return didAdd;
					}
				}
				
				list.add(contact);
			}
			return didAdd;
			
		}
	}


