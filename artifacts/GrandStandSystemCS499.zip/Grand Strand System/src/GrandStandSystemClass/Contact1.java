package GrandStandSystemClass;

import java.util.HashMap;

import java.util.Map;
// New system implements for Cs 499
//Implementing contact functions
public class Contact1 {
	private String id;
	private String name;
	private String email;
	private String phone;
	
	public Contact1(String id, String name, String email, String phone) {
		this.id = id;
		this.name = name;
		this.email = email;
		this.phone = phone;
		
	}
	
	public String getId() {
		return id;
		
	}
	
	public String getName() {
		return name;
	}
	
	public String getEmail() {
		return email;
	}
	
	public String getPhone() {
		return phone;
		
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	@Override
	public String toString() {
		return "Contact1{" +
				"id='" + id + '\''+
				", name='" + name + '\''+
				", email='" + email + '\'' +
				", phone= '" + phone + '\'' +
				'}';
	}

}
//add new contact
class ContactManagementSystem {
	private Map<String, Contact1> contacts;
	
	public ContactManagementSystem() {
		contacts = new HashMap<>();
	}
	
	public void addContact(Contact1 contact) {
		contacts.put(contact.getId(), contact);
	}
	
	// search for contact and information
	public Contact1 searchContact(String id) {
		return contacts.get(id);
	}
	//update contact
	public void updateContact(String id, String name, String email,String phone) {
		Contact1 contact = contacts.get(id);
		if(contact !=null) {
			if (name !=null) {
				contact.setName(name);
			}
			
			if (email != null) {
				contact.setEmail(email);
			}
			
			if (phone != null ) {
				contact.setPhone(phone);
			}
		}
		
	}
	//delete contact
	public void deleteContact(String id) {
		contacts.remove(id);
	}
	
	// display contact
	public void displayContacts() {
		for(Contact1 contact : contacts.values()) {
			System.out.println(contact);
		}
	}
}
