package GrandStandSystemClass;

public class Task {
	private String ContactId;
	private String fullName;
	private String description;
	//setting public task
	public Task(String id, String fullName, String description2) {
		// TODO Auto-generated constructor stub
		
	}
	private final boolean validateID(String ContactId) {
		if(ContactId == null || ContactId.length() > 10) {
			 throw new IllegalArgumentException("Invalid ID");	
		}
		return true;
	}
	private final boolean validatefullName(String fullName) {
		if(fullName == null || fullName.length() > 20) {
			throw new IllegalArgumentException("Invalid Full Name");
		
		}
		return true;
	}
	private final boolean validateDescription(String description) {
		if(description == null || description.length() > 50) {
			throw new IllegalArgumentException("Invalid Description");
			
		}
		return true;
	}

	//set ID with unique ID
	
	public String getContactId(){
	return ContactId;
	}
	//setting name with full name
	public String getfullName() {
	return fullName;
	}
	public String getdescription() {
	return description;
	}

//setting public ID with using integers

public int getUniqueID() {
	return Integer.valueOf(ContactId);
	
}

private void setID(String uniqueID) {
	this.ContactId = uniqueID;
}
//setting public void full name 

public void getfullName(String fullName) {
	
	this.fullName = fullName;
}
//public string to get description

public String getDescription() {
	return description;
}

public void setDescription(String description) {
	if(!this.validateDescription(description)) {
		throw new IllegalArgumentException ("Invalid Description");
	}
	this.description = description;
}
//recomendations added from debugging code
public static String getID() {
	// TODO Auto-generated method stub
	return null;
}
public Object getName() {
	// TODO Auto-generated method stub
	return null;
}

}


