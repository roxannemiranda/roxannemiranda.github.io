package GrandStandSystemClass;

public class Contact {
	
		private String ContactId;
		private String firstName;
		private String lastName;
		private String number;
		private String address;
		
		// creating a class with the contact
		
		public Contact(String ContactId, String firstName, String lastName, String number, String address) {
			// if contact Id is null, and contact ID is 10 character
			if(ContactId == null || ContactId.length() > 10) {
				//argument if contact ID is incorrect
			 throw new IllegalArgumentException("Invalid ID");
			}
			// creating a class with first Name
			if(firstName == null|| firstName.length() > 10) {
				throw new IllegalArgumentException("Invalid firstName");
			}

			if(lastName == null || lastName.length() > 10) {
				throw new IllegalArgumentException("Invalid lastName");
				
			}
		
			if(number ==null || number.length() !=10) {
				throw new IllegalArgumentException ("Invalid Phone Number");
				
				
			}
			if(address == null || address.length() > 30) {
				// Address is 30 characters
				throw new IllegalArgumentException ("Invalid Address") ;
				
			}
		
		 this.ContactId = ContactId;
		 this.firstName = firstName;
		 this.lastName = lastName;
		 this.number = number;
		 this.address = address;
					
		}

	//Accessor Methods	

			//return public string for ContactID
			public String  getContactId() {
				return ContactId;
			}
			//return public string for First Name
			public String getFirstName() {
				return firstName;
			}
			//return public string for Last Name
			public String getLastName() {
				return lastName;
			}
			//return public string for Number
			public String getNumber () {
				return number;
			}
			//return public string for Address
			public String getAddress() {
				return address;
			}

// setter methods
	public void setContactId(String ContactId) {
		if(ContactId == null || ContactId.length() > 10) {
			throw new IllegalArgumentException("ID is invalid");
		}
		this.ContactId = ContactId;
	}
	
	public void setfirstName(String firstName) {
		if(firstName == null || firstName.length() > 10) {
			throw new IllegalArgumentException("First Name is invalid");
			
		}
		this.firstName = firstName;
	}
	
	public void setlastName(String lastName) {
		if(lastName == null || lastName.length() > 10) {
			throw new IllegalArgumentException("Last Name is invalid");
			
		}
		this.lastName = lastName;
			
		}
	
	public void setNumber(String number) {
		if(number == null || number.length() > 10) {
			throw new IllegalArgumentException("This Number is invalid");
		}
		this.number = number;
	}
	
	public void setaddress(String address) {
		if(address == null || address.length() > 30) {
			throw new IllegalArgumentException("This Address is invalid");	
		}
		
		this.address = address;
	}
	}